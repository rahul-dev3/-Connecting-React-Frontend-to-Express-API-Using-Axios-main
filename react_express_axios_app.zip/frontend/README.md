# Connecting React Frontend to Express API Using Axios

## Objective
Learn how to connect a React frontend to an Express.js backend using Axios for API requests.

## Folder Structure
```
react_express_axios_app/
├── backend/
│   ├── server.js
│   └── package.json
└── frontend/
    ├── src/
    │   ├── App.js
    │   ├── index.js
    │   └── components/ProductList.js
    └── package.json
```

## Setup

### Backend
```bash
cd backend
npm install
npm start
```

### Frontend
```bash
cd frontend
npm install
npm start
```

Make sure backend is running on port 5000 before starting the frontend.

## Expected Output
The React app fetches and displays products from the Express API with name and price.
